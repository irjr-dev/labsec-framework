from colorama import init, Fore, Back, Style
import threading
import subprocess
import os

class Floodconnect():
	target = ""
	port = ""
	
	def __info(self):
		print("""
OPTIONS INFO

[+] target: Dirección ip del host objetivo.

 Ejemplos de seteo			 Comentarios
 -----------------------------		-----------------------------
 [-] set target 192.168.1.105		 Dirección ip del objetivo

[+] port: Puerto objetivo.

 Ejemplos de seteo			 Comentarios
 -----------------------------		-----------------------------
 [-] set port 23		 Puerto objetivo

""")

	def options(self, info=""):
		if info[0] == "info":
			self.__info()
		else:
			print("""
 Opciones del Modulo:

 Nombre		Valor 			Descripción
 ------		-----			-----------
 target		{:<15}		Dirección ip del host objetivo
 port		{:<15}		Puerto objetivo

 Para más información acerca de las opciones escriba el comando: {}options info{}
			""".format(self.target, self.port, Fore.YELLOW, Fore.RESET))


	def set(self,args):
		try:
			if args[0] == "target":
				self.target = args[1]
				print("[+] target:",args[1])
			elif args[0] == "port":
				self.port = args[1]
				print("[+] port:",args[1])
			else:
				print("'{}' no es una opción valida".format(args[0]))
		except Exception as e:
			print("ERROR!",e)
			print("El comando debe tener la siguiente sintaxis: set <option name> <value>")

	def run(self):
		try:

			comando = 'python3 modulos/dos/_floodconnect.py ' + self.target + ' ' + self.port
			def proceso():
				subprocess.run(['xterm', '-e', comando])
			hilo = threading.Thread(target=proceso)
			hilo.setDaemon(True)
			hilo.start()
		except Exception as e:
			print(e)
			input()